from ecommerce import sale
from ecommerce.sale import sell, buy
import ecommerce.sale

ecommerce.sale.sell()


sell()


sale.buy()

print(dir(sale))
