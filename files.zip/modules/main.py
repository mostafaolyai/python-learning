from m1 import fun1, fun2

fun2()
