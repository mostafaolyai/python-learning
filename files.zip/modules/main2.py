import m1

m1.fun1()
