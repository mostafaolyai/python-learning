def fun1(self):
    print('fun1')


def fun2(self):
    print('fun1')
