def buy():
    print('buy')


def sell():
    print('sell')
